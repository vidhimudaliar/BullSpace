document.addEventListener("DOMContentLoaded", () => {
  console.log("Availability map loaded.");
});